import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';

const app = express();
const port = 5000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const url = 'mongodb://localhost:27017/streetfighter';

mongoose.connect(url)
    .then(() => console.log("Se ha establecido la conexión con la base de datos"))
    .catch(error => console.error('Error al conectar a MongoDB:', error));

const gameSchema = new mongoose.Schema({
    date: { type: Date, default: Date.now },
    player1: { type: String, required: true },
    player2: { type: String, required: true },
    result: { type: String, required: true }
});

const Game = mongoose.model('Game', gameSchema);

app.use(express.static(path.join(__dirname, 'pantallacarga')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'pantallacarga', 'login.html'));
});

app.get('/carga', (req, res) => {
    res.sendFile(path.join(__dirname, 'pantallacarga', 'carga.html'));
});

app.get('/explicacion', (req, res) => {
    res.sendFile(path.join(__dirname, 'explicacion', 'explicacion.html'));
});

app.get('/juego', (req, res) => {
    res.sendFile(path.join(__dirname, 'juego', 'index.html'));
});

app.get('/record', (req, res) => {
    res.sendFile(path.join(__dirname, 'record', 'record.html'));
});

app.post('/api/saveGame', async (req, res) => {
    const { player1, player2, result } = req.body;

    if (!player1 || !player2 || !result) {
        return res.status(400).send('Todos los campos son obligatorios');
    }

    try {
        const nuevaPartida = new Game({ player1, player2, result });
        await nuevaPartida.save();
        res.status(201).json(nuevaPartida);
    } catch (error) {
        console.error('Error al añadir nueva partida:', error);
        res.status(500).send('Error interno del servidor');
    }
});

app.get('/api/getGames', async (req, res) => {
    try {
        const gameRecords = await Game.find({});
        res.status(200).json(gameRecords);
    } catch (error) {
        console.error('Error al obtener los registros de partidas:', error);
        res.status(500).send('Error interno del servidor');
    }
});

app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});
