import mongoose from 'mongoose';


const userSchema = new mongoose.Schema({
    date: { type: Date, default: Date.now },
    player1: { type: String, required: true },
    player2: { type: String, required: true },
    result: { type: String, required: true }
});

const Partida = mongoose.model('user', userSchema);

export default Partida;
