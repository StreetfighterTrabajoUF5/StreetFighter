document.addEventListener('DOMContentLoaded', ()=> {
    const background = document.getElementById('background');
    background.src = './img/Fondo.webp'
})

