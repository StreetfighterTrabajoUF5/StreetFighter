import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import bodyParser from 'body-parser';
import mongoose from 'mongoose';
import { StatusBar } from './pantallacarga/juego/overlays/StatusBar.js';

const statusbar = new StatusBar();
const end = statusbar.endGame();
const endKen = statusbar.endGameForKen();
const endRyu = statusbar.endGameForRyu();

const app = express();
const port = 5000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const url = 'mongodb://localhost:27017/streetfighter';

mongoose.connect(url)
    .then(() => console.log("Se ha establecido la conexion con la base de datos"))
    .catch(error => console.error('Error al conectar a MongoDB:', error));

const userSchema = new mongoose.Schema({
    nombre: { type: String, required: true, unique: true },
    contrasenya: { type: String, required: true, unique: true }
});

const user = mongoose.model('user', userSchema);

app.use(express.static(path.join(__dirname, 'pantallacarga')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/pantallacarga', 'carga.html'));


});

// Ruta para el archivo explicacion.html en la carpeta explicacion
app.get('/explicacion', (req, res) => {
    res.sendFile(path.join(__dirname, 'explicacion', 'explicacion.html'));
});

// Ruta para el archivo index.html en la carpeta juego
app.get('/juego', (req, res) => {
    res.sendFile(path.join(__dirname, 'juego', 'index.html'));


});

/*app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../pantallacarga', 'carga.html'));
});*/


// Rutas condicionales
if (statusbar.endGameForRyu()) {
    app.get('/', (req, res) => {
            res.sendFile(path.join(__dirname, './carga.html'));
    });
}



app.listen(port, () => {
    console.log(`Servidor ejecutándose en http://localhost:${port}`);
});
