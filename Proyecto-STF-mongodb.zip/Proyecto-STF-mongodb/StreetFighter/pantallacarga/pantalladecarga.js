// Importamos la función createElement de React y el elemento del DOM donde se montará la aplicación
const el = React.createElement;
const domContainer = document.getElementById('carga');

// Componente para la pantalla de carga
const BackgroundImage = () => {
  return el(
    'div',
    {
      // Estilos para la imagen de fondo
      style: {
        backgroundImage: 'url(./img/ryuyken.gif)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0
      }
    },
    // Componentes secundarios: Logo, Start , AudioControls y copy
    el(Text, { text: "© 2024 StreetFighter. Todos los derechos reservados." }),
    el(Logo, { style: { position: 'absolute', top: '20%', left: '50%', transform: 'translate(-50%, -50%)' } }),
    el(Start, { style: { position: 'absolute', top: '65%', left: '50%', transform: 'translate(-50%, -50%)' } }),
    el(Historial, { style: { position: 'absolute', top: '75%', left: '50%', transform: 'translate(-50%, -50%)' } }),
    el(Volver, { style: { position: 'absolute', top: '85%', left: '50%', transform: 'translate(-50%, -50%)' } }),
    el(AudioControls, { style: { position: 'absolute', top: '80%', left: '97%', transform: 'translate(-50%, -50%)' } })
  );
};

// Componente para el enlace de inicio
const Start = ({ style }) => {
  return el(
    'a',
    {
      style: {
        backgroundImage: 'url(./img/start.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: '20%',
        height: '10%',
        ...style
      },
      href: '../explicacion/explicacion.html',
      onClick: (e) => {
        e.preventDefault(); // Previene la acción predeterminada del enlace
        window.location.href = '../explicacion/explicacion.html'; // Redirige al usuario al juego
      }
    }
  );
};
// Componente para el enlace de inicio
const Historial = ({ style }) => {
  return el(
    'a',
    {
      style: {
        backgroundImage: 'url(./img/historial.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: '30%',
        height: '10%',
        ...style
      },
      href: '../record/record.html',
      onClick: (e) => {
        e.preventDefault(); // Previene la acción predeterminada del enlace
        window.location.href = '../record/record.html'; // Redirige al usuario al juego
      }
    }
  );
};
// Componente para el enlace de inicio
const Volver = ({ style }) => {
  return el(
    'a',
    {
      style: {
        backgroundImage: 'url(./img/exitgame.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: '26.5%',
        height: '10%',
        ...style
      },
      href: '../record/record.html',
      onClick: (e) => {
        e.preventDefault(); // Previene la acción predeterminada del enlace
        window.location.href = '../login.html'; // Redirige al usuario al juego
      }
    }
  );
};
// Componente para el logotipo
const Logo = ({ style }) => {
  return el(
    'div',
    {
      style: {
        backgroundImage: 'url(./img/logo2pixel.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: '50%',
        height: '40%',
        marginTop: '20px',
        ...style
    }
    },
    null
  );
};

// Componente para los controles de audio
const AudioControls = ({ style }) => {
  // Referencia al elemento de audio
  const audioRef = React.useRef(true);
  // Estado para controlar si el audio está silenciado
  const [isMuted, setIsMuted] = React.useState(false);
  // Estado para controlar el volumen del audio
  const [volume, setVolume] = React.useState(0.5);

  // Efecto para reproducir la música de fondo al cargar la página
  React.useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.5;
      audioRef.current.play();
    }
  }, []);

  // Manejador de clics para silenciar/desmutear el audio
  const handleMuteToggle = () => {
    if (!isMuted) {
      audioRef.current.pause(); // Pausa la reproducción del audio
      audioRef.current.volume = volume;
    } else {
      audioRef.current.play(); // Reanuda la reproducción del audio
      
    }
    setIsMuted(!isMuted); // Cambia el estado de silencio
  };

  // Manejador para cambiar el volumen
  const handleVolumeChange = (event) => {
    const newVolume = parseFloat(event.target.value);
    if (!isMuted) {
      audioRef.current.volume = newVolume; // Actualiza el volumen si no está silenciado
    }
    setVolume(newVolume); // Actualiza el estado del volumen
  };

  // Función para obtener la imagen del botón de silencio según el estado de silencio y el volumen
  const getVolumeImage = () => {
    if (isMuted || volume <= 0) {
      return './musica/mute.png'; // Imagen de silencio si está silenciado o el volumen es 0
    } else if (volume > 0.6) {
      return './musica/sonidoalto.png'; // Imagen de volumen alto
    } else if (volume > 0.2 && volume <= 0.6) {
      return './musica/sonidomedio.png'; // Imagen de volumen medio
    } else {
      return './musica/sonidobajo.png'; // Imagen de volumen bajo
    }
  };

  // Devuelve los elementos de los controles de audio
  return el(
    'div',
    {
      // Estilos para el contenedor de los controles de audio
      style: {
        backgroundColor: 'rgba(255, 255, 255, 0.8)', // Fondo blanco semitransparente
        borderRadius: '10px', // Esquinas redondeadas
        width: '25px',
        height: '250px',
        padding: '10px', // Espaciado dentro del contenedor
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        ...style // Estilos adicionales proporcionados como propiedades
      }
    },
    // Elemento de audio para la música de fondo
    el('audio', {
      ref: audioRef,
      src: './musica/bandasonora.mp3',
      loop: true,
      autoPlay: true, // Reproducción automática al cargar la página
    }),
    // Control deslizante de volumen
    el('input', {
      type: 'range',
      min: '0',
      max: '1',
      step: '0.1',
      value: volume,
      onChange: handleVolumeChange,
      style: {
        width: '200px',
        transform: 'rotate(-90deg)',
        position: 'relative',
        margin: '20px 0',
        top: '28%', left: '6%'
      },
    }),
    // Botón de silencio
    el('img', {
      onClick: handleMuteToggle, // Manejador de clics para silenciar/desmutear
      src: getVolumeImage(), // Imagen del botón de silencio según el estado
      alt: 'Volume Level', // Texto alternativo para la imagen
      style: { width: '50px', height: '50px', cursor: 'pointer', position: 'absolute', top: '85%', left: '50%', transform: 'translate(-50%, -50%)' }
    })
  );

  
};

const Text = ({ text }) => {
  const [displayedText] = React.useState(text); 

  return el('div', {
    style: {
      fontFamily: '"Press Start 2P", monospace', // Fuente retro
      color: 'white',
      textAlign: 'center',
      width: '90%',
      position: 'absolute',
      top: '96%',
      left: '15%',
      transform: 'translate(-50%, -50%)'
    }
  }, displayedText);
};

// Renderiza el componente BackgroundImage en el contenedor del DOM
ReactDOM.render(el(BackgroundImage), domContainer);
