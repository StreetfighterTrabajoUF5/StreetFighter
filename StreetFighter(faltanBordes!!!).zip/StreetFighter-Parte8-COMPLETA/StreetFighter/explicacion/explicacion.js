// Importamos la función createElement de React y el elemento del DOM donde se montará la aplicación
const el = React.createElement;
const domContainer = document.getElementById('explicacion');

// Componente para la pantalla de carga
const BackgroundImage = () => {
  return el(
    'div',
    {
      // Estilos para la imagen de fondo
      style: {
        backgroundImage: 'url(./img/pantallacarga.jpeg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#00ff00', // Color del texto retro
        fontFamily: 'Press Start 2P', // Fuente retro
        fontSize: '18px', // Tamaño del texto
        whiteSpace: 'pre-wrap', // Para respetar los saltos de línea
        padding: '20px' // Padding para el texto
      }
    },
    // Componentes secundarios: Logo, Start y el texto animado
    el(Logo, { style: { position: 'absolute', top: '20%', left: '50%', transform: 'translate(-50%, -50%)' } }),
    el(TextAnimation, { text: "Bienvenido al StreetFighter 7!!! El juego trata sobre lucha entre dos personajes llamados Ryu y Ken, los controles son los siguientes: para Ryu, saltar la tecla W , para ir marcha atrás la A , para ir adelante la D  y para agacharte la S . Si quieres hacer un salto hacia adelante pulsa D+W y para atrás A+W. Para Ken utilizaremos la flecha hacia arriba  para saltar, para ir marcha atrás la flecha izquierda , para adelante la flecha derecha y para agacharte la flecha hacia abajo. Para los saltos hacia adelante usa las flechas izquierda y arriba  y para atrás las flechas derecha e izquierda." }),
    el(Start, { style: { position: 'absolute', top: '92%', left: '90%', transform: 'translate(-50%, -50%)' } }),
    el(Audio)
  );
};

// Componente para el enlace de inicio
const Start = ({ style }) => {
  return el(
    'a',
    {
      style: {
        backgroundImage: 'url(./img/start.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: '14%',
        height: '7%',
        ...style
      },
      href: '../juego/index.html',
      onClick: (e) => {
        e.preventDefault(); // Previene la acción predeterminada del enlace
        window.location.href = '../juego/index.html'; // Redirige al usuario al juego
      }
    }
  );
};

// Componente para el logotipo
const Logo = ({ style }) => {
  return el(
    'div',
    {
      style: {
        backgroundImage: 'url(./img/logo.png)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        width: '50%',
        height: '40%',
        ...style
      }
    },
    null
  );
};

// Componente para la animación de texto
const TextAnimation = ({ text }) => {
  const [displayedText, setDisplayedText] = React.useState('');

  React.useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      setDisplayedText((prev) => prev + text[i]);
      i++;
      if (i == text.length) {
        clearInterval(timer);
      }
    }, 50); // Velocidad de la animación (50ms por carácter)
    return () => clearInterval(timer);
  }, [text]);

  return el('div', {
    style: {
     fontFamily: '"Press Start 2P", monospace', // Fuente retro
      color: 'white',
      textAlign: 'center',
      width: '90%',
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)'
    }
  }, displayedText);
};

const Audio = ({ style }) => {
  // Referencia al elemento de audio
  const audioRef = React.useRef(true);
  React.useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.5;
      audioRef.current.play();
    }
  }, []);

  // Devuelve los elementos de los controles de audio
  return el(
    'audio',
    {
      ref: audioRef,
      src: './musica/bandasonora.mp3',
      loop: true,
      autoPlay: true, // Reproducción automática al cargar la página
    },
   
    
 
  );

  
};

// Renderiza el componente BackgroundImage en el contenedor del DOM
ReactDOM.render(el(BackgroundImage), domContainer);
