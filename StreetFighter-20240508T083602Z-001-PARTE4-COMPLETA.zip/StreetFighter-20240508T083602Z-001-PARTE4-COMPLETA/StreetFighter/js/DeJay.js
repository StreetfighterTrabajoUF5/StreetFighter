import { Fighter } from './fighter.js';

export class DeJay extends Fighter {
    constructor(x, y, velocity) {
        super('dejay',x, y, velocity)
        this.image = document.querySelector('img[alt="dejay"]');

        //Modificación
        this.frames = new Map([
            // Move Forwards
            ['forwards-1', [25, 550, 60, 101]],
            ['forwards-2', [113, 548, 66, 103]],
            ['forwards-3', [202, 545, 83, 104]],
            ['forwards-4', [309, 546, 91, 102]],
            ['forwards-5', [426, 549, 90, 99]],
            ['forwards-6', [426, 549, 90, 99]],

            // MoveBackwards 
            ['backwards-1', [22, 702, 68, 101]],
            ['backwards-2', [118, 704, 90, 99]],
            ['backwards-3', [230, 700, 91, 103]],
            ['backwards-4', [353, 698, 87, 105]],
            ['backwards-5', [422, 699, 72, 104]],
            ['backwards-6', [574, 701, 68, 102]],
        ]);

        this.animations = {
            'walkForwards': ['forwards-1', 'forwards-2', 'forwards-3', 'forwards-4', 'forwards-5', 'forwards-6'],
            'walkBackwards': ['backwards-1', 'backwards-2', 'backwards-3', 'backwards-4', 'backwards-5', 'backwards-6'],
        };
    }
}

