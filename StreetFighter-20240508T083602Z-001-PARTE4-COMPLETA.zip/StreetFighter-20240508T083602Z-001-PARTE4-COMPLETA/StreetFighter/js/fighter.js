import { FighterDirection } from "../constants/fighter.js";

export class Fighter {
    constructor(name, x, y, direction) {
        this.name = name;
        this.image = new Image();
        //Modificación
        this.frames = new Map();
        this.position = {x, y};
        this.direction = direction;
        this.velocity = 150 * direction;
        //Modificación
        this.animationFrame = 0;
        this.animationTimer = 0;
        this.animations = {};
        this.state = this.changeState();
    }

    changeState = () => this.velocity * this.direction < 0 ? 'walkBackwards' : 'walkForwards';

    update(time, context) {
        //Modificación
        const [, , width] = this.frames.get(this.animations[this.state][this.animationFrame]);

        //Modificación
        if (time.previous > this.animationTimer + 60) {
            this.animationTimer = time.previous;
            
            //Modificación
            this.animationFrame++;
            if (this.animationFrame > 5) this.animationFrame = 0;
        }
    
        this.position.x += this.velocity * time.secondsPassed;

        if(this.position.x > context.canvas.width - width / 2 ) {
            this.velocity = -150;
            this.state = this.changeState();
        }

        if (this.position.x < width / 2) {
            this.velocity = 150;
            this.state = this.changeState();
        }
    }

    // Modificación
    drawDebug(context) {
        context.lineWidth = 1;

        context.beginPath();
        context.strokeStyle = 'white';
        context.moveTo(Math.floor(this.position.x) - 4.5, Math.floor(this.position.y));
        context.lineTo(Math.floor(this.position.x) + 4.5, Math.floor(this.position.y));
        context.moveTo(Math.floor(this.position.x), Math.floor(this.position.y - 4.5));
        context.lineTo(Math.floor(this.position.x), Math.floor(this.position.y + 4.5));
        context.stroke();
    }

    draw(context) {
        const [x, y, width, height] = this.frames.get(this.animations[this.state][this.animationFrame]);
        /*
        const [
            [x, y, width, height]
            [originX, originY]
        ] = this.frames.get(`forwards-${this.animationFrame}`);
         */
        
        context.scale(this.direction, 1);
        context.drawImage(
            this.image, 
            x, y, 
            width, height, 
            Math.floor(this.position.x * this.direction), Math.floor(this.position.y), 
            width, height
        );

        /*
        context.drawImage (
            this.image, 
            x, y, 
            width, height, 
            this.position.x -originX, this.position.y - originY, 
            width, height
        );
        */

        context.setTransform(1, 0 , 0, 1, 0, 0);

        this.drawDebug(context);
    }
}