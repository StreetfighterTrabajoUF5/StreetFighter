import { Fighter } from './fighter.js';

export class Sagat extends Fighter {
    constructor(x, y, velocity) {
        super('sagat',x, y, velocity)
        this.image = document.querySelector('img[alt="sagat"]');

        //Modificación
        this.frames = new Map([
            // Move Forwards
            ['forwards-1', [13, 647, 74, 119]],
            ['forwards-2', [103, 646, 71, 121]],
            ['forwards-3', [199, 645, 62 ,123]],
            ['forwards-4', [282, 644, 65 ,124]],
            ['forwards-5', [373, 645, 62, 123]],
            ['forwards-6', [451, 646, 71, 121]],

            // Move Backwards
            ['backwards-1', [13, 647, 74, 119]],
            ['backwards-2', [103, 646, 71, 121]],
            ['backwards-3', [199, 645, 62 ,123]],
            ['backwards-4', [282, 644, 65 ,124]],
            ['backwards-5', [373, 645, 62, 123]],
            ['backwards-6', [451, 646, 71, 121]],
        ]);

        this.animations = {
            'walkForwards': ['forwards-1', 'forwards-2', 'forwards-3', 'forwards-4', 'forwards-5', 'forwards-6'],
            'walkBackwards': ['backwards-1', 'backwards-2', 'backwards-3', 'backwards-4', 'backwards-5', 'backwards-6'],
        };
    }
}


