import { Fighter } from './fighter.js';

export class Ken extends Fighter {
    constructor(x, y, velocity) {
        super('ken',x, y, velocity)
        this.image = document.querySelector('img[alt="ken"]');

        //Modificación
        this.frames = new Map([
            // Move Forwards - KEN 
            ['forwards-1', [[16, 162, 53, 83], [27, 81]]],
            ['forwards-2', [[77, 157, 60, 88], [35, 86]]],
            ['forwards-3', [[141, 155, 64, 90], [35, 67]]],
            ['forwards-4', [[217, 156, 63, 89], [29, 88]]],
            ['forwards-5', [[288, 156, 54, 89], [25, 87]]],
            ['forwards-6', [[350, 156, 50, 89], [25, 86]]],

            // Move Backwards - KEN
            ['backwards-1', [[448, 158, 61, 87], [35, 85]]],
            ['backwards-2', [[517, 155, 59, 90], [36, 87]]],
            ['backwards-3', [[584, 155, 57, 90], [36, 88]]],
            ['backwards-4', [[649, 155, 58, 90], [36, 89]]],
            ['backwards-5', [[715, 154, 58, 91], [36, 88]]],
            ['backwards-6', [[781, 156, 57, 89], [36, 87]]],
        ]);

        this.animations = {
            'walkForwards': ['forwards-1', 'forwards-2', 'forwards-3', 'forwards-4', 'forwards-5', 'forwards-6'],
            'walkBackwards': ['backwards-1', 'backwards-2', 'backwards-3', 'backwards-4', 'backwards-5', 'backwards-6'],
        };
    }
}


