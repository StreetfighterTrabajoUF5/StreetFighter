import { Fighter } from './fighter.js';

export class Ryu extends Fighter {
    constructor(x, y, velocity) {
        super('ryu',x, y, velocity)
        this.image = document.querySelector('img[alt="ryu"]');

        //Modificación
        this.frames = new Map([
            // Move Forwards - RYU
            ['forwards-1', [[9, 136, 53, 83], [27, 81]]],
            ['forwards-2', [[78, 131, 60, 89], [35, 86]]],
            ['forwards-3', [[152, 128, 64, 92], [35, 89]]],
            ['forwards-4', [[229, 130, 63, 90], [29, 89]]],
            ['forwards-5', [[307, 128, 54, 91], [25, 89]]],
            ['forwards-6', [[371, 128, 50, 89], [25, 86]]],

            // MoveBackwards - RYU
            ['backwards-1', [[777, 128, 61, 87], [35, 85]]],
            ['backwards-2', [[430, 124, 59, 90], [36, 87]]],
            ['backwards-3', [[495, 124, 57, 90], [36, 88]]],
            ['backwards-4', [[559, 125, 58, 90], [36, 89]]],
            ['backwards-5', [[631, 125, 58, 91], [36, 88]]],
            ['backwards-6', [[707, 126, 57, 89], [36, 87]]],
        ]);

        this.animations = {
            'walkForwards': ['forwards-1', 'forwards-2', 'forwards-3', 'forwards-4', 'forwards-5', 'forwards-6'],
            'walkBackwards': ['backwards-1', 'backwards-2', 'backwards-3', 'backwards-4', 'backwards-5', 'backwards-6'],
        };
    }
}

