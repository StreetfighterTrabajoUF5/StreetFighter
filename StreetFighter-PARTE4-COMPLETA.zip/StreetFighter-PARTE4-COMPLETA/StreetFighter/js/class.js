class Personaje {
    constructor(nombre, vida, ataque, habilidad) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
        this.habilidad = habilidad;
    }
    getNombre() {
        return this.nombre;
    }
    getVida() {
        return this.vida;
    }
    setVida(vida) {
        this.vida = vida;
    }
    
    getAtaque() {
        return this.ataque;
    }
    setAtaque(ataque) {
        this.ataque = ataque;
    }
    
    getHabilidad() {
        return this.habilidad
    }
    setHabilidad(habilidad) {
        this.habilidad = habilidad;
    }
}

class Personaje1 extends Personaje{
    constructor(nombre,vida,ataque,habilidad){
        super(nombre,vida,ataque,habilidad)
    }
}

class Personaje2 extends Personaje{
    constructor(nombre,vida,ataque,habilidad){
        super(nombre,vida,ataque,habilidad)
    }
}