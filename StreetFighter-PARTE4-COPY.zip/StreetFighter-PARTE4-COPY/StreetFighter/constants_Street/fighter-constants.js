export const FighterDirection = {
    LEFT: -1,
    RIGHT: 1
};