export const STAGE_FLOOR = 200;
