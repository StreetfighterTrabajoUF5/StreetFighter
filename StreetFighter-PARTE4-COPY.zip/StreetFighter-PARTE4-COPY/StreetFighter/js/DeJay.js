import { Fighter } from './fighter.js';

export class DeJay extends Fighter {
    constructor(x, y, velocity) {
        super('dejay',x, y, velocity)
        this.image = document.querySelector('img[alt="dejay"]');

        // MODIFICACIÓN : HAY QUE REVISAR DE NUEVOOOO
        this.frames = new Map([
            // Move forwards
            ['forwards-1', [[0, 0, 71, 101],[71, 101]]],
            ['forwards-2', [[0, 0, 53, 103],[53, 103]]],
            ['forwards-3', [[0, 0, 53, 103],[53, 103]]],
            ['forwards-4', [[0, 0, 57, 103],[57, 103]]],
            ['forwards-5', [[0, 0, 57, 103],[57, 103]]],
            ['forwards-6', [[0, 0, 53, 103],[53, 103]]],

            //Move Backwards
            ['backwards-1', [[0, 0, 71, 101],[71, 101]]],
            ['backwards-2', [[0, 0, 53, 103],[53, 103]]],
            ['backwards-3', [[0, 0, 53, 103],[53, 103]]],
            ['backwards-4', [[0, 0, 57, 103],[57, 103]]],
            ['backwards-5', [[0, 0, 57, 103],[57, 103]]],
            ['backwards-6', [[0, 0, 53, 103],[53, 103]]],
        ]);

        // Modificación
        this.animations = {
            'walkForwards': ['forwards-1', 'forwards-2', 'forwards-3', 'forwards-4', 'forwards-5', 'forwards-6'],
            'walkBackwards': ['backwards-1', 'backwards-2', 'backwards-3', 'backwards-4', 'backwards-5', 'backwards-6'],
        }
    }
}

