//import { FighterDirection } from "../constants_Street/fighter-constants.js";

export class Fighter {
    constructor(name, x, y, direction) {
        this.name = name;
        this.image = new Image();
        // we add a variable "frame" where there will be an array 
        this.frames = new Map();
        this.position = {x, y};
        this.direction = direction;
        // Modificación
        this.velocity = 150 * direction;
        // Modificación 
        this.animationFrame = 0;
        //Modificación 
        this.animationTimer = 0;
        //Modificación
        this.animations = {};
        //Modificación
        this.state = this.changeState();
    }

    //Modificación
    changeState = () => this.velocity * this.direction < 0 ? 'walkBackwards' : 'walkForwards';

    update(time, context) {
        //Modificación
        const[[, , width]] = this.frames.get(this.animations[this.state][this.animationFrame]);

        //Modificación 
        if (time.previous > this.animationTimer + 60) {
            this.animationTimer = time.previous;
            
            //Modificación
            this.animationFrame++;
            if (this.animationFrame > 6) this.animationFrame = 1;
        }

        this.position.x += this.velocity * time.secondsPassed;

        //Modificación
        if(this.position.x > context.canvas.width - width / 2) {
            this.velocity = 150;
            this.state = this.changeState();
        }

        //Modificación
        if (this.position.x < width / 2) {
            this.velocity = 150;
            this.state = this.changeState();
        }
    }
    
    //Modificación
    drawDebug(context) {
        context.lineWidth = 1;

        context.beginPath();
        context.strokeStyle = 'white';
        // Modificación
        context.moveTo(Math.floor(this.position.x) - 4.5, Math.floor(this.position.y));
        context.LineTo(Math.floor(this.position.x) + 4.5, Math.floor(this.position.y));
        context.moveTo(Math.floor(this.position.x), Math.floor(this.position.y) - 4.5);
        context.LineTo(Math.floor(this.position.x), Math.floor(this.position.y) + 4.5);
        context.stroke();
    }

    // MODIFICACIÓN
    draw(context) {
        const[
            [x, y, width, height],
            [originX, originY], 
        ]= this.frames.get(this.animations[this.state][this.animationFrame]);

        //MODIFICACIÓN
        context.scale(this.direction, 1);

        //MODIFICACIÓN
        context.drawImage(
            this.image, 
            x, y, 
            width, height, 
            Math.floor(this.position.x * this.direction) - originX, Math.floor(this.position.y) - originY, 
            width, height
        );
        //Modificación
        context.setTransform(1, 0, 0, 1, 0, 0,); 

        this.drawDebug(context);
    }
}