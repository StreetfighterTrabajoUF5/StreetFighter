import { Sagat } from "./sagat.js";
import { DeJay } from "./DeJay.js";
import { Stage} from "./stage.js";
import { FpsCounter } from "./FpsCounter.js";
import { STAGE_FLOOR } from "../constants_Street/stage.js";
import { FighterDirection } from "../constants_Street/fighter-constants.js";

// SE PUEDE AÑADIR ESTA PARTE AL INDEX.HTML Y COMENTAR O BORRAR ESTE CODIGO
const GameViwerPort = {
    width: 770,
    height: 500,
};

window.addEventListener('load', function() {
    const canvasElement = document.querySelector('canvas');
    const context = canvasElement.getContext('2d');
    // Modificación 
    context.imageSmoothingEnabled = false;
    
    canvasElement.width = GameViwerPort.width;
    canvasElement.height = GameViwerPort.height;

    // MODIFICARLO Y DEJARLO COMO ESTABA ANTES , CON LA VIEJA VERSION
    //Modificación
    const stage = new Stage();
    const sagat = new Sagat(104, STAGE_FLOOR, FighterDirection.LEFT);
    const dejay = new DeJay(280, STAGE_FLOOR, FighterDirection.RIGHT);
    const fpscounter = new FpsCounter();
    
    /*const entities = [
        new Stage(),
        new Sagat(104, STAGE_FLOOR, FighterDirection.LEFT),
        new DeJay(280, STAGE_FLOOR, FighterDirection.RIGHT),
        new FpsCounter(),
    ]*/
    
    //Modificación
    let previousTime = 0;
    let secondsPassed = 0;
    /*let frameTime = {
        previous: 0,
        secondsPassed: 0,
    };*/

    function frame(time) {
        window.requestAnimationFrame(frame);
        
        //Modificacion
        secondsPassed = (time - previousTime) / 1000;
        previousTime = time;
        /*frameTime = {
            secondsPassed: (time - frameTime.previous) / 1000,
            previous: time,
        };*/ 

        //Modificación
        sagat.update(secondsPassed, context)
        dejay.update(secondsPassed, context)

        stage.draw(context)
        sagat.draw(context);
        dejay.draw(context);
        fpscounter.update(secondsPassed);
        fpscounter.draw(context);

        /*for (const entity of entities) {
            entity.upate(frameTime, context);
        }

        for (const entity of entities) {
            entity.draw(context);
        }*/
    
        console.log(time)
    }    
    window.requestAnimationFrame(frame);
});