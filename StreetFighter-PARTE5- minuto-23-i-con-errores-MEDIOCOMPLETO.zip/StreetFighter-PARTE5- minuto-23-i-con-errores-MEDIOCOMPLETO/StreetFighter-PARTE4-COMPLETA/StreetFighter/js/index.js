import { Ken } from "./Ken.js";
import { Ryu } from "./Ryu.js"; 
import { Stage } from "./stage.js";
import { FpsCounter } from "./FpsCounter.js";
import { STAGE_FLOOR } from "../constants/stage.js";
import { FighterDirection, FighterState } from "../constants/fighter.js";

//añade los valores de ir para adelante o para atras al dropdown
function populateMoveDropdown() {
    const dropdown = document.getElementById('state-dropdown');
    
    Object.entries(FighterState).forEach(([, value]) => {
        const option = document.createElement('option');
        option.setAttribute('value', value);
        option.innerText = value;
        dropdown.appendChild(option);  
    });
}

//cuando seleccionas a los personajes por checkbox y se mueven
function handleFormSubmit(event, fighters) {
    event.preventDefault();

    const selectedCheckboxes = Array
    .from(event.target.querySelectorAll('input:checked'))
    .map(checkbox => checkbox.value);

    const options = event.target.querySelector('select');

    fighters.forEach(fighter => {
        if (selectedCheckboxes.includes(fighter.name)) {
            fighter.changeState(options.value);
        }
    });
}

window.addEventListener('load', function() {
    populateMoveDropdown();
    const canvasElement = document.querySelector('canvas');
    const context = canvasElement.getContext('2d');

    if (!context) {
        console.error('No se pudo obtener el contexto del canvas');
        return;
    }

    context.imageSmoothingEnabled = false;

    const fighters = [
        new Ken(1000, STAGE_FLOOR, FighterDirection.LEFT),
        new Ryu(0, STAGE_FLOOR, FighterDirection.RIGHT),
    ];

    const entities = [
        new Stage(),
        ...fighters,
        new FpsCounter(),
    ];

    let frameTime = {
        previous: 0,
        secondsPassed: 0,
    };

    function frame(time) {
        window.requestAnimationFrame(frame);
        
        frameTime = {
            previous: time,
            secondsPassed: (time - frameTime.previous) / 1000,
        };

        for (const entity of entities) {
            entity.update(frameTime, context);
            entity.draw(context);
        }
    }

    document.addEventListener('submit', (event) => handleFormSubmit(event, fighters));

    window.requestAnimationFrame(frame);
});
