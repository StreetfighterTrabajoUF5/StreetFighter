import { Ken } from "./Ken.js";
import { Ryu } from "./Ryu.js"; 
import { KenStage } from "./stage/Kenstage.js";
import { FpsCounter } from "./FpsCounter.js";
import { STAGE_MID_POINT, STAGE_PADDING } from "../constants/stage.js";
import { pollGamepads, registerGamepadEvents, registerKeyboardEvents } from "../engine/inputHandler.js";
import { Shadow } from "./Shadow.js";
import { StatusBar } from "../overlays/StatusBar.js";
import { Camera } from "../engine/Camera.js";
import { getContext } from "./utils/context.js";


export class StreetFighterGame {
    context = getContext();
    fighters = [new Ryu(0), new Ken(1)];
    camera = new Camera(STAGE_MID_POINT + STAGE_PADDING - (this.context.canvas.width / 2), 16, this.fighters);
    frameTime = {
        previous: 0,
        secondsPassed: 0,
    };

    constructor(){
this.stage = new KenStage();

        this.fighters[0].opponent = this.fighters[1];
        this.fighters[1].opponent = this.fighters[0];
     
         this.entities = [
            ...this.fighters.map(fighter => new Shadow(fighter)),
            ...this.fighters,
            
        ];
     
        this.overLays = [
            new StatusBar(this.fighters),
            new FpsCounter(),
        ]
    }

    update(){
        this.camera.update(this.frameTime, this.context);
        this.stage.update(this.frameTime, this.context);

        for (const entity of this.entities){
            entity.update(this.frameTime, this.context, this.camera);
        }
        for (const overlay of this.overLays){
            overlay.update(this.frameTime, this.context, this.camera);
        }
    }

    draw(){
        this.stage.drawBackground(this.context, this.camera)
        for (const entity of this.entities){
            entity.draw(this.context, this.camera);
        }
        this.stage.drawForeground(this.context,this.camera);
        for (const overlay of this.overLays){
            overlay.draw(this.context, this.camera);
        }
    }

    frame(time){
        window.requestAnimationFrame(this.frame.bind(this));

        this.frameTime = {
            secondsPassed: (time - this.frameTime.previous) / 1000,
            previous: time,
        }

        pollGamepads();
        this.update();
        this.draw();
    }


    start(){
        registerKeyboardEvents();
        //Modificación
        registerGamepadEvents();

        window.requestAnimationFrame(this.frame.bind(this));
    }
}