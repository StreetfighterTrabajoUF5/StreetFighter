import { KenStage } from "../js/stage/Kenstage";
import { Ken } from "../js/Ken.js";
import { Ryu } from "../js/Ryu.js";
import { Camera } from "../engine/Camera.js";
import { Shadow } from "../js/Shadow.js";


export class BattleScene {
    fighters = [];
    camera = undefined;
    shadows = [];

    constructor() {
        this.stage = new KenStage();

        this.overLays = [
            new StatusBar(this.fighters),
            new FpsCounter(),
        ];

        this.fighters = this.getFighterEntities();
        // -192 = 384/2 = 192
        this.camera = new Camera(STAGE_MID_POINT + STAGE_PADDING - 192, 16, this.fighters);
        this.shadows = this.fighters.map(fighter => new Shadow(fighter));

    }

    getFighterEntities() {
        const fighterEntities = [new Ryu(0), new Ken(1)];
    
        this.fighters[0].opponent = this.fighters[1];
        this.fighters[1].opponent = this.fighters[0];

        return fighterEntities;
    }

    updateFighters(time, context) {
        for (const fighter of this.fighters) {
            fighter.update(time, context, this.camera);
        }
    }

    updateShadows(time, context) {
        for (const shadow of this.shadows) {
            shadow.update(time, context, this.camera);
        }
    }

    updateEntities(time, context) {
        for (const entity of this.entities) {
            entity.update(time, context, this.camera);
        }
    }

    updateOverlays(time, context) {
        for(const overlay of this.overlays) {
            overlay.update(time, context, this.camera);
        }
    }

    update(time, context) {
        this.updateFighters(time, context);
        this.updateShadows(time, context);
        this.stage.update(time);
        this.updateEntities(time, context);
        this.camera.update(time);
        this.updateOverlays(time, context);
    }

    drawFighters(context) {

    }
    drawShadows(context) {
        
    }

    draw(context) {

    }
}