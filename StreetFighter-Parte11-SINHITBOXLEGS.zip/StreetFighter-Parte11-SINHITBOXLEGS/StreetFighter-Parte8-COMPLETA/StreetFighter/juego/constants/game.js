export const FPS = 60;
export const FRAME_TIME = 1000 / FPS;
