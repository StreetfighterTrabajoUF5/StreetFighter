const objectEntity = {
    position: {x: 0, y: 0},
    velocity: 1,
    draw() { },
}

const entity = function() {};

entity.prototype.position = { x: 0, y: 0};
entity.prototype.velocity = 1;
entity.prototype.draw = function() { };

const sagat = new entity();

class Entity {
    constructor() {
        this.position = { x: 0, y: 0 };
        this.velocity = 1;
    }

    // DEJAR ESTA PARTE!! FUNCIONA ASI
    update(){
        
    }

    draw() {

    }
}

const dejay = new Entity();