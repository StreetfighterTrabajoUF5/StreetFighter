import { Fighter } from './fighter.js';
import { FighterState } from "../constants/fighter.js";
export class Ken extends Fighter {
    constructor(x, y, direction, playerId) {
        super('Ken',x, y, direction, playerId)
        this.image = document.querySelector('img[alt="ken"]');

        //Modificación
        this.frames = new Map([
            // Move Idle - KEN 
            ['idle-1', [[347, 25, 60, 89], [34, 86]]],
            ['idle-2', [[16, 24, 59, 90], [33, 87]]],
            ['idle-3', [[82, 22, 58, 92], [32, 89]]],
            ['idle-4', [[151, 21, 55, 93], [31, 90]]],
            ['idle-5', [[218, 22, 58, 92], [30, 91]]],
            ['idle-6', [[284, 21, 55, 93], [29, 92]]],
              
            // Move Forwards - KEN 
            ['forwards-1', [[16, 162, 53, 83], [27, 81]]],
            ['forwards-2', [[77, 157, 60, 88], [35, 86]]],
            ['forwards-3', [[141, 155, 64, 90], [35, 87]]],
            ['forwards-4', [[217, 156, 63, 89], [29, 88]]],
            ['forwards-5', [[288, 156, 54, 89], [25, 87]]],
            ['forwards-6', [[350, 156, 50, 89], [25, 86]]],

            // Move Backwards - KEN
            ['backwards-1', [[448, 158, 61, 87], [35, 85]]],
            ['backwards-2', [[517, 155, 59, 90], [36, 87]]],
            ['backwards-3', [[584, 155, 57, 90], [36, 88]]],
            ['backwards-4', [[649, 155, 58, 90], [36, 89]]],
            ['backwards-5', [[715, 154, 58, 91], [36, 88]]],
            ['backwards-6', [[781, 156, 57, 89], [36, 87]]],

            // Move Jump Up - KEN            
            ['jump-up-1', [[16, 1610, 55, 85], [32, 107]]],
            ['jump-up-2', [[79, 1586, 56, 104], [25, 103]]],
            ['jump-up-3', [[143, 1549, 50, 89], [25, 103]]],
            ['jump-up-4', [[201, 1527, 54, 77], [28, 101]]],
            ['jump-up-5', [[263, 1524, 48, 70], [28, 103]]],
            ['jump-up-6', [[319, 1534, 48, 86], [25, 107]]],
            ['jump-up-7', [[375, 1560, 55, 103], [28, 103]]],
            ['jump-up-8', [[438, 1610, 55, 85], [25, 107]]],

            // Move Jump Forward-Backward - KEN
            ['jump-roll-1', [[16, 2261, 55, 85], [25, 106 ]]],
            ['jump-roll-2', [[79, 2238, 55, 103], [22, 90 ]]],
            ['jump-roll-3', [[142, 2198, 61, 78 ], [61, 76 ]]],
            ['jump-roll-4', [[211, 2204, 104, 42], [42, 111 ]]],
            ['jump-roll-5', [[323, 2167, 53, 82], [71, 81 ]]],
            ['jump-roll-6', [[384, 2198, 122, 44], [53, 98]]],
            ['jump-roll-7', [[514, 2183, 71, 87 ], [32, 107]]],
            ['jump-roll-8', [[593, 2188, 55, 103], [28, 98]]],
            ['jump-roll-9', [[656, 2261, 55, 85 ], [25, 107]]],
 
            //Jump First/last frame
            ['jump-land', [[16, 1610, 55, 85], [29, 83]]],

            // Crouch - KEN
            ['crouch-1', [[16, 1131, 53, 83], [27, 81]]],
            ['crouch-2', [[77, 1145, 57, 69], [25, 66]]],
            ['crouch-3', [[145, 1153, 61, 61], [25, 58]]],

            // Stand Turn 
            ['idle-turn-1', [[453, 19, 54, 95], [29, 92]]],
            ['idle-turn-2', [[515, 16, 58, 98], [30, 95]]],
            ['idle-turn-3', [[581, 20, 54, 94], [27, 90]]],

            // Crouch Turn 
            ['crouch-turn-1', [[251, 1153, 53, 61], [26, 58]]],
            ['crouch-turn-2', [[312, 1153, 52, 61], [27, 58]]],
            ['crouch-turn-3', [[372, 1153, 53, 61], [29, 58]]],
        ]);

        this.animations = {
            [FighterState.IDLE]: [
                ['idle-1', 68], ['idle-2', 68], ['idle-3', 68], 
                ['idle-4', 68], ['idle-5', 68], ['idle-6', 68],
            ],
            [FighterState.WALK_FORWARD]: [
                ['forwards-1', 65], ['forwards-2', 65], ['forwards-3', 65], 
                ['forwards-4', 65], ['forwards-5', 65], ['forwards-6', 65],
            ],
            [FighterState.WALK_BACKWARD]: [
                ['backwards-1', 65], ['backwards-2', 65], ['backwards-3', 65], 
                ['backwards-4', 65], ['backwards-5', 65], ['backwards-6', 65],
            ],
            [FighterState.JUMP_START]:[
                ['jump-land', 50], ['jump-land', -2],
            ],
            [FighterState.JUMP_UP]: [
                ['jump-up-1', 180], ['jump-up-2', 100], ['jump-up-3', 100], 
                ['jump-up-4', 100], ['jump-up-5', 100], ['jump-up-6', 100],
                ['jump-up-7', 100], ['jump-up-8', -1],
            ],
            [FighterState.JUMP_FORWARD]: [
                ['jump-roll-1', 200], ['jump-roll-2', 50], ['jump-roll-3', 50], 
                ['jump-roll-4', 50], ['jump-roll-5', 50], ['jump-roll-6', 50],
                ['jump-roll-7', 50], ['jump-roll-8', 50], ['jump-roll-9', 0],
            ],
            [FighterState.JUMP_BACKWARD]: [
                ['jump-roll-9', 200], ['jump-roll-8', 50], ['jump-roll-7', 50], 
                ['jump-roll-6', 50], ['jump-roll-5', 50], ['jump-roll-4', 50],
                ['jump-roll-3', 50], ['jump-roll-2', 50], ['jump-roll-1', 0],
            ],
            [FighterState.JUMP_LAND]:[
                ['jump-land', 33], ['jump-land', 117],
                ['jump-land', -2]
            ],
            [FighterState.CROUCH]: [['crouch-3', 0]],
            [FighterState.CROUCH_DOWN]: [
                ['crouch-1', 30], ['crouch-2', 30], ['crouch-3', 30], ['crouch-3', -2],
            ],
            [FighterState.CROUCH_UP]: [
                ['crouch-3', 30], ['crouch-2', 30], ['crouch-1', 30], ['crouch-1', -2],
            ],
            [FighterState.IDLE_TURN]: [
                ['idle-turn-3', 33], ['idle-turn-2', 33],
                ['idle-turn-1', 33], ['idle-turn-1',  0], // AnimationFrame.TRANSITION
            ],
            [FighterState.CROUCH_TURN]: [
                ['crouch-turn-3', 33], ['crouch-turn-2', 33],
                ['crouch-turn-1', 33], ['crouch-turn-1',  0],// AnimationFrame.TRANSITION
            ],
        };

    

        this.initialVelocity = {
            x: {
                [FighterState.WALK_FORWARD]: 200,
                [FighterState.WALK_BACKWARD]: -150,
                [FighterState.JUMP_FORWARD]: 170,
                [FighterState.JUMP_BACKWARD]: -200,
            },
            jump: -340,
        }

        this.gravity = 1000;
    }
}


