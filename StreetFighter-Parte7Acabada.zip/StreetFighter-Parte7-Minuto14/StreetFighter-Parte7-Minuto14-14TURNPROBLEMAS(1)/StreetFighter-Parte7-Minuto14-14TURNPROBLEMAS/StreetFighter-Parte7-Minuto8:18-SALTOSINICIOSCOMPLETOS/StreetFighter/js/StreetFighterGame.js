import { Ken } from "./Ken.js";
import { Ryu } from "./Ryu.js"; 
import { Stage } from "./stage.js";
import { FpsCounter } from "./FpsCounter.js";
import { STAGE_FLOOR } from "../constants/stage.js";
import { FighterDirection } from "../constants/fighter.js";
import { pollGamepads, registerGamepadEvents, registerKeyboardEvents } from "./inputHandler.js";
import { Shadow } from "./Shadow.js";
//import { Fighter } from "./fighter.js";


export class StreetFighterGame {
    constructor(){
    this.context = this.getContext();
    this.fighters = [
        new Ken(1000, STAGE_FLOOR, FighterDirection.LEFT, 0),
        new Ryu(0, STAGE_FLOOR, FighterDirection.RIGHT, 1), 
    ];

    this.fighters[0].opponent = this.fighters[1];
    this.fighters[1].opponent = this.fighters[0];

    this.entities = [
        new Stage(),
        //Modificación
        ...this.fighters.map(fighter => new Shadow(fighter)),
        ...this.fighters,
        new FpsCounter(),
    ];
    this.frameTime = {
        previous: 0,
        secondsPassed: 0,
    };
}

getContext(){
    const canvasEl = document.querySelector('canvas');
    const context = canvasEl.getContext('2d');

    context.imageSmoothingEnabled = false;

    return context;
}

update(){
    for (const entity of this.entities){
        entity.update(this.frameTime, this.context);
    }
}

draw(){
    for (const entity of this.entities){
        entity.draw(this.context);
    }
}

frame(time){
    window.requestAnimationFrame(this.frame.bind(this));

    this.frameTime = {
        secondsPassed: (time - this.frameTime.previous) / 1000,
        previous: time,
    }

    pollGamepads();
    this.update();
    this.draw();
}


start(){
    registerKeyboardEvents();
    //Modificación
    registerGamepadEvents();

    window.requestAnimationFrame(this.frame.bind(this));
}
}