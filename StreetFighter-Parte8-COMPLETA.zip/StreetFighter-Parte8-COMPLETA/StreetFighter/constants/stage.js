export const STAGE_FLOOR = 200;

export const STAGE_WIDTH = 768;
export const STAGE_HEIGHT = 256;
export const STAGE_MID_POINT = STAGE_WIDTH / 2;
export const STAGE_PADDING = 256;

export const SCROLL_BOUNDRY = 100;