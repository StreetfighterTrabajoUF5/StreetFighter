import { StreetFighterGame } from "./StreetFighterGame.js";


window.addEventListener('load', function() {
    new StreetFighterGame().start();

});
