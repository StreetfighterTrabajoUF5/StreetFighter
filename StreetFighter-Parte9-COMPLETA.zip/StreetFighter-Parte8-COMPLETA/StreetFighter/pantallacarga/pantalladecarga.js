const el = React.createElement;
const domContainer = document.getElementById('carga');

const BackgroundImage = () => {
  return el(
    'div',
    {
      style: {
        backgroundImage: 'url(./img/pantallacarga.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0
      }
    },
    el(Logo, { style: { position: 'absolute', top: '20%', left: '50%', transform: 'translate(-50%, -50%)' } }),
    el(Start, { style: { position: 'absolute', top: '75%', left: '50%', transform: 'translate(-50%, -50%)' }})
  );
};

const Start = ({ style }) =>
 { return el( 
  'a',
   { style: {
     backgroundImage: 'url(./img/start.png)', 
     backgroundSize: 'cover',
      backgroundPosition: 'center',
      width: '20%', 
      height: '10%', ...style
      }, 
      href: '../juego/index.html', onClick: (e) => {  
      e.preventDefault();  window.location.href = '../juego/index.html';
      } } ); };
       
const Logo = ({ style }) => {
    return el(
      'div',
      {
        style: {
          backgroundImage: 'url(./img/logo.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          width: '50%',
          height: '40%',
          ...style
        }
      },
      null
    );
  };



function SubirVolumen(medio) {
    if (medio.volume < 1) {
        medio.volume += 0.1;
    }
}

function BajarVolumen(medio) {
    if (medio.volume > 0) {
        medio.volume -= 0.1;
    }
}

function Sonido(medio) {
    SubirVolumen(medio);
    BajarVolumen(medio);
}

ReactDOM.render(el(BackgroundImage), domContainer);


