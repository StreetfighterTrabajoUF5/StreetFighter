class BackGround {
    constructor(x, y, width, height) {
        this.img = new Image()
        this.img.src = './ken.jpeg'
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        this.img.onload = () => {
            this.draw(context);
        };
    }

    draw(context) {
        context.drawImage(this.img, this.x, this.y, this.width, this.height);
    }
}