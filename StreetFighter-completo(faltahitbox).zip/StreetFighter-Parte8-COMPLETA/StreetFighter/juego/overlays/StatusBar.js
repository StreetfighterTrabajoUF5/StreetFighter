import { 
    HEALTH_CRITICAL_HIT_POINTS, 
    HEALTH_DAMAGE_COLOR, 
    HEALTH_MAX_HIT_POINTS, 
    KO_ANIMATION, 
    KO_FLASH_DELAY, 
    TIME_DELAY, 
    TIME_FLASH_DELAY, 
    TIME_FRAME_KEYS 
} from "../constants/battle.js";
import { FPS } from "../constants/game.js";

import { gameState } from "../state/gameState.js";
import { getContext, drawFrame } from '../js/utils/context.js'; // Asegúrate de importar las funciones necesarias

export class StatusBar {
    time = 99;
    timeTimer = 0;
    timeFlashTimer = 0;
    useFlashFrames = false;

    healthBars = [{
        timer: 0,
        hitPoints: HEALTH_MAX_HIT_POINTS,
    }, {
        timer: 0,
        hitPoints: HEALTH_MAX_HIT_POINTS,
    }];

    koFrame = 0;
    koAnimationTimer = 0;
    gameOver = false; // Nueva propiedad para controlar el estado del juego

    frames = new Map([
        ['health-bar', [16, 18, 145, 11]],

        ['ko-white', [161, 16, 32, 14]],
        ['ko-red', [161, 1, 32, 14]],

        [`${TIME_FRAME_KEYS[0]}-0`, [16, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-1`, [32, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-2`, [48, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-3`, [64, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-4`, [80, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-5`, [96, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-6`, [112, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-7`, [128, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-8`, [144, 32, 14, 16]],
        [`${TIME_FRAME_KEYS[0]}-9`, [160, 32, 14, 16]],

        //Time Flash
        [`${TIME_FRAME_KEYS[1]}-0`, [16, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-1`, [32, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-2`, [48, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-3`, [64, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-4`, [80, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-5`, [96, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-6`, [112, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-7`, [128, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-8`, [144, 192, 14, 16]],
        [`${TIME_FRAME_KEYS[1]}-9`, [168, 192, 14, 16]],

        //Numeric
        ['score-0', [17,101,10,10]],
        ['score-1', [29,101,10,10]],
        ['score-2', [41,101,10,10]],
        ['score-3', [53,101,10,10]],
        ['score-4', [65,101,11,10]],
        ['score-5', [77,101,10,10]],
        ['score-6', [89,101,10,10]],
        ['score-7', [101,101,10,10]],
        ['score-8', [113,101,10,10]],
        ['score-9', [125,101,10,10]],
            
        //Alpha
        ['score-@', [17,113,10,10]],
        ['score-A', [29,113,10,10]],
        ['score-B', [41,113,10,10]],
        ['score-C', [53,113,10,10]],
        ['score-D', [65,113,10,10]],
        ['score-E', [77,113,10,10]],
        ['score-F', [89,113,10,10]],
        ['score-G', [101,113,10,10]],
        ['score-H', [113,113,10,10]],
        ['score-I', [125,113,9,10]],
        ['score-J', [136,113,10,10]],
        ['score-K', [149,113,10,10]],
        ['score-L', [161,113,10,10]],
        ['score-M', [173,113,10,10]],
        ['score-N', [185,113,11,10]],
        ['score-O', [197,113,10,10]],
        ['score-P', [17,125,10,10]],
        ['score-Q', [29,125,10,10]],
        ['score-R', [41,125,10,10]],
        ['score-S', [53,125,10,10]],
        ['score-T', [65,125,10,10]],
        ['score-U', [77,125,10,10]],
        ['score-V', [89,125,10,10]],
        ['score-W', [101,125,10,10]],
        ['score-X', [113,125,10,10]],
        ['score-Y', [125,125,10,10]],
        ['score-Z', [136,125,10,10]],

        // Name tags
        ['tag-ken', [128, 56, 30, 9]],
        ['tag-ryu', [16, 56, 28, 9]],
    ]);

    constructor() {
        this.image = document.querySelector('img[alt="misc"]');
        this.names = gameState.fighters.map(({ id }) => `tag-${id.toLowerCase()}`);
    }

    updateTime(time) {
        if (this.gameOver) return; // No actualizar el tiempo si el juego ha terminado

        if(time.previous > this.timeTimer + TIME_DELAY) {
            this.time -= 1;
            this.timeTimer = time.previous;
        }
        if (this.time <= 0) {
            this.endGameForDraw();
            return;
        }
        if (
            this.time < 15 && this.time > -1
            && time.previous > this.timeFlashTimer + TIME_FLASH_DELAY 
        ) {
            this.useFlashFrames = !this.useFlashFrames;
            this.timeFlashTimer = time.previous;
        }
    }

    updateHealthBars(time) {
        if (this.gameOver) return; // No actualizar las barras de vida si el juego ha terminado

        for (const index in this.healthBars) {
            if (this.healthBars[index].hitPoints <= gameState.fighters[index].hitpoints) continue;
            this.healthBars[index].hitPoints = Math.max(0, this.healthBars[index].hitPoints - (time.secondsPassed * FPS));

            // Verificar si la barra de vida de un personaje ha llegado a 0 o menos
            if (this.healthBars[index].hitPoints <= 0) {
                this.endGame(index === '0' ? 1 : 0); // Pasar el índice del ganador
                return;
            }
        }
    }

    updateKoIcon(time) {
        if (this.gameOver) return; // No actualizar el icono KO si el juego ha terminado

        if (this.healthBars.every((healthBar) => healthBar.hitPoints > HEALTH_CRITICAL_HIT_POINTS)) return;
        if (time.previous < this.koAnimationTimer + KO_FLASH_DELAY[this.koFrame]) return;

        this.koFrame = 1 - this.koFrame;
        this.koAnimationTimer = time.previous;
    }
    endGame(winnerIndex) {
        this.gameOver = true; // Marcar el juego como terminado
    
     
        if (winnerIndex >= 0 && winnerIndex < gameState.fighters.length) {
            const winner = gameState.fighters[winnerIndex];
            if (winner) {
                const winnerName = winner.id.toLowerCase();
                switch (winnerName) {
                    case 'ryu':
                        this.endGameForRyu();
                        break;
                    case 'ken':
                        this.endGameForKen();
                        break;
                    default:
                        alert(`${winnerName} ha ganado!`);
                }
            } else {
                alert('Ganador no identificado');
            }
        } else {
            alert('Índice del ganador no válido');
        }
    }
  
    

    endGameForDraw() {
        // Pausar el juego
        this.gameOver = true;
    
        // Ocultar el canvas
        const canvas = document.querySelector('canvas');
        canvas.style.display = 'none';
    
        // Establecer el estilo para el fondo
        document.body.style.background = 'url(./overlays/img/pantallacarga.jpeg)';
        document.body.style.backgroundSize = 'cover';
        document.body.style.backgroundPosition = 'center'; // Centrar la imagen de fondo
        document.body.style.color = 'white';
      
    
        // Crear un contenedor para la información sobre el empate
        const infoContainer = document.createElement('div');
        infoContainer.id = 'draw-info';
        infoContainer.style.position = 'fixed';
        infoContainer.style.top = '50%';
        infoContainer.style.left = '50%';
        infoContainer.style.transform = 'translate(-50%, -50%)'; // Centrar vertical y horizontalmente
        infoContainer.style.zIndex = '10000'; // Asegurar que esté por encima del fondo
    
        // Agregar título "Empate"
        const drawTitle = document.createElement('h1');
        drawTitle.textContent = 'EMPATE';
        drawTitle.style.fontSize = '48px'; // Tamaño grande
        drawTitle.style.textAlign = 'center'; // Centrado
        infoContainer.appendChild(drawTitle);
    
        // Mostrar el puntaje de ambos luchadores
        const ryuScore = gameState.fighters[0].score;
        const kenScore = gameState.fighters[1].score;
    
        // Puntaje de Ryu
        const ryuScoreLabel = document.createElement('p');
        ryuScoreLabel.textContent = `Puntaje Ryu: ${ryuScore}`;
        ryuScoreLabel.style.fontSize = '24px'; // Tamaño grande
        ryuScoreLabel.style.textAlign = 'center'; // Centrado
        infoContainer.appendChild(ryuScoreLabel);
    
        // Puntaje de Ken
        const kenScoreLabel = document.createElement('p');
        kenScoreLabel.textContent = `Puntaje Ken: ${kenScore}`;
        kenScoreLabel.style.fontSize = '24px'; // Tamaño grande
        kenScoreLabel.style.textAlign = 'center'; // Centrado
        infoContainer.appendChild(kenScoreLabel);
    
        // Mostrar los puntajes gradualmente
        let currentRyuScore = 0;
        let currentKenScore = 0;
        const scoreInterval = setInterval(function() {
            ryuScoreLabel.textContent = `Puntaje Ryu: ${currentRyuScore}`;
            kenScoreLabel.textContent = `Puntaje Ken: ${currentKenScore}`;
            currentRyuScore += 10; // Incremento más rápido
            currentKenScore += 10; // Incremento más rápido
            if (currentRyuScore > ryuScore && currentKenScore > kenScore) {
                clearInterval(scoreInterval);
            }
        }, 50);
    
        // Agregar un botón retro atractivo para volver a empezar
        const button = document.createElement('button');
        button.textContent = 'VOLVER A EMPEZAR';
        button.style.fontFamily = 'Press Start 2P'; // Establecer la fuente
        button.style.fontSize = '24px'; // Tamaño grande
        button.style.backgroundColor = 'black';
        button.style.color = 'white';
        button.style.border = '2px solid white';
        button.style.borderRadius = '4px';
        button.style.padding = '10px 20px';
        button.style.cursor = 'pointer';
        button.style.display = 'block'; // Mostrar como bloque para centrar
        button.style.margin = '0 auto'; // Centrar horizontalmente
        button.onclick = function() {
            // Reanudar el juego y redirigir a otra página cuando se hace clic en el botón
            this.gameOver = false;
            canvas.style.display = ''; // Restaurar la visualización del canvas
            infoContainer.remove(); // Eliminar el contenedor de información
            window.location.href = 'StreetFighter/../../pantallacarga/carga.html'; // Reemplazar con la URL de la otra página
        }.bind(this); // Enlazar correctamente la función al contexto actual
        infoContainer.appendChild(button); // Agregar el botón al contenedor
    
        // Agregar el contenedor al cuerpo del documento
        document.body.appendChild(infoContainer);
    }
    
endGameForRyu(){
    // Pausar el juego
    this.gameOver = true;

    // Ocultar el canvas
    const canvas = document.querySelector('canvas');
    canvas.style.display = 'none';

    // Crear un elemento de estilo para cargar la fuente localmente
    

    // Establecer el estilo para el fondo
    document.body.style.background = 'url(./overlays/img/pantallacarga.jpeg)';
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundPosition = 'center'; // Centrar la imagen de fondo
    document.body.style.color = 'white';
  

    // Crear un contenedor para la información sobre Ken
    const infoContainer = document.createElement('div');
    infoContainer.id = 'ryu-info';
    infoContainer.style.position = 'fixed';
    infoContainer.style.top = '50%';
    infoContainer.style.left = '50%';
    infoContainer.style.transform = 'translate(-50%, -50%)'; // Centrar vertical y horizontalmente
    infoContainer.style.zIndex = '10000'; // Asegurar que esté por encima del fondo

    // Agregar título "Ganador Ryu"
    const winnerTitle = document.createElement('h1');
    winnerTitle.textContent = 'Ganador RYU';
    winnerTitle.style.fontSize = '48px'; // Tamaño grande
    winnerTitle.style.textAlign = 'center'; // Centrado
    infoContainer.appendChild(winnerTitle);

    // Mostrar el puntaje de Ryu
    const ryuScore = gameState.fighters[0].score;
    const scoreLabel = document.createElement('p');
    scoreLabel.textContent = `Puntaje: ${ryuScore}`;
    scoreLabel.style.fontSize = '24px'; // Tamaño grande
    scoreLabel.style.textAlign = 'center'; // Centrado
    infoContainer.appendChild(scoreLabel);

    let currentScore = 0;
    const scoreInterval = setInterval(function() {
        scoreLabel.textContent = `Puntaje: ${currentScore}`;
        currentScore += 10; // Incremento más rápido
        if (currentScore > ryuScore) {
            clearInterval(scoreInterval);
        }
    }, 50);

    // Agregar un botón retro atractivo para ir a otra página
    const button = document.createElement('button');
    button.textContent = 'VOLVER A EMPEZAR';
    button.style.fontSize = '24px'; // Tamaño grande
    button.style.backgroundColor = 'black';
    button.style.color = 'white';
    button.style.border = '2px solid white';
    button.style.borderRadius = '4px';
    button.style.padding = '10px 20px';
    button.style.cursor = 'pointer';
    button.style.display = 'block'; // Mostrar como bloque para centrar
    button.style.margin = '0 auto'; // Centrar horizontalmente
    button.onclick = function() {
        // Reanudar el juego y redirigir a otra página cuando se hace clic en el botón
        this.gameOver = false;
        canvas.style.display = ''; // Restaurar la visualización del canvas
        infoContainer.remove(); // Eliminar el contenedor de información
        window.location.href = 'StreetFighter/../../pantallacarga/carga.html'; // Reemplaza 'otra_pagina.html' con la URL de la otra página
    }.bind(this); // Enlazar correctamente la función al contexto actual
    infoContainer.appendChild(button); // Agregar el botón al contenedor


    
    // Agregar el contenedor al cuerpo del documento
    document.body.appendChild(infoContainer);
}

   
endGameForKen() {
    // Pausar el juego
    this.gameOver = true;

    // Ocultar el canvas
    const canvas = document.querySelector('canvas');
    canvas.style.display = 'none';

   

    // Establecer el estilo para el fondo
    document.body.style.background = 'url(./overlays/img/pantallacarga.jpeg)';
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundPosition = 'center'; // Centrar la imagen de fondo
    document.body.style.color = 'white';
  

    // Crear un contenedor para la información sobre Ken
    const infoContainer = document.createElement('div');
    infoContainer.id = 'ken-info';
    infoContainer.style.position = 'fixed';
    infoContainer.style.top = '50%';
    infoContainer.style.left = '50%';
    infoContainer.style.transform = 'translate(-50%, -50%)'; // Centrar vertical y horizontalmente
    infoContainer.style.zIndex = '10000'; // Asegurar que esté por encima del fondo

    // Agregar título "Ganador Ken"
    const winnerTitle = document.createElement('h1');
    winnerTitle.textContent = 'Ganador KEN';
    winnerTitle.style.fontSize = '48px'; // Tamaño grande
    winnerTitle.style.textAlign = 'center'; // Centrado
    infoContainer.appendChild(winnerTitle);

    // Mostrar el puntaje de Ken
    const kenScore = gameState.fighters[1].score;
    const scoreLabel = document.createElement('p');
    scoreLabel.textContent = `Puntaje: ${kenScore}`;
    scoreLabel.style.fontSize = '24px'; // Tamaño grande
    scoreLabel.style.textAlign = 'center'; // Centrado
    infoContainer.appendChild(scoreLabel);

    let currentScore = 0;
    const scoreInterval = setInterval(function() {
        scoreLabel.textContent = `Puntaje: ${currentScore}`;
        currentScore += 10; // Incremento más rápido
        if (currentScore > kenScore) {
            clearInterval(scoreInterval);
        }
    }, 50);

    // Agregar un botón retro atractivo para ir a otra página
    const button = document.createElement('button');
    button.textContent = 'VOLVER A EMPEZAR';
    button.style.fontFamily = 'Press Start 2P'; // Establecer la fuente
    button.style.fontSize = '24px'; // Tamaño grande
    button.style.backgroundColor = 'black';
    button.style.color = 'white';
    button.style.border = '2px solid white';
    button.style.borderRadius = '4px';
    button.style.padding = '10px 20px';
    button.style.cursor = 'pointer';
    button.style.display = 'block'; // Mostrar como bloque para centrar
    button.style.margin = '0 auto'; // Centrar horizontalmente
    button.onclick = function() {
        // Reanudar el juego y redirigir a otra página cuando se hace clic en el botón
        this.gameOver = false;
        canvas.style.display = ''; // Restaurar la visualización del canvas
        infoContainer.remove(); // Eliminar el contenedor de información
        window.location.href = 'StreetFighter/../../pantallacarga/carga.html'; // Reemplaza 'otra_pagina.html' con la URL de la otra página
    }.bind(this); // Enlazar correctamente la función al contexto actual
    infoContainer.appendChild(button); // Agregar el botón al contenedor


    
    // Agregar el contenedor al cuerpo del documento
    document.body.appendChild(infoContainer);
}


    update(time) {
        this.updateTime(time);
        this.updateHealthBars(time);
        this.updateKoIcon(time);
    }
    
    drawFrame(context, frameKey, x, y, direction = 1) {
        drawFrame(context, this.image, this.frames.get(frameKey), x, y, direction);
    }

    drawHealthBars(context) {
        this.drawFrame(context, 'health-bar', 31, 20);
        this.drawFrame(context, KO_ANIMATION[this.koFrame], 176, 18 - this.koFrame);
        this.drawFrame(context, 'health-bar', 353, 20, -1);

        context.fillStyle = HEALTH_DAMAGE_COLOR;

        context.beginPath();
        context.fillRect (
            32, 21,
            HEALTH_MAX_HIT_POINTS - Math.floor(this.healthBars[0].hitPoints), 9,
        );

        context.fillRect(
            208 + Math.floor(this.healthBars[1].hitPoints), 21,
            HEALTH_MAX_HIT_POINTS - Math.floor(this.healthBars[1].hitPoints), 9,
        );
    }

    drawNameTags(context) {
        const [name1, name2] = this.names;

        this.drawFrame(context, name1, 32, 33);
        this.drawFrame(context, name2, 322, 33);
    }

    drawTime(context) {
        const timeString = String(Math.max(this.time, 0)).padStart(2, '00');
        const flashFrame = TIME_FRAME_KEYS[Number(this.useFlashFrames)];

        this.drawFrame(context, `${flashFrame}-${timeString.charAt(0)}`, 178, 33);
        this.drawFrame(context, `${flashFrame}-${timeString.charAt(1)}`, 194, 33);
    }

    drawScoreLabel(context, name, x){
        for (const index in name) {
            this.drawFrame(context,`score-${name.charAt(index)}`, x + index * 12, 1);
        }
    }

    drawScore(context, score, x){
        if (score < 1) return;

        const strScore = String(score);
        const padding = ((6 * 12) - String(score).length * 12);

        this.drawScoreLabel(context, strScore, x + padding);
    }

    drawScores(context){
        this.drawScoreLabel(context,'P1', 4);
        this.drawScore(context, gameState.fighters[0].score, 45);

        this.drawScoreLabel(context,'ANT', 133);
        this.drawScore(context,50000, 177);

        this.drawScoreLabel(context,'P2', 269);          
        this.drawScore(context, gameState.fighters[1].score, 309);

    }

    draw(context) {
        this.drawScores(context);
        this.drawHealthBars(context);
        this.drawNameTags(context);
        this.drawTime(context);
    }
}
