import { Fighter } from './fighter.js';

export class DeJay extends Fighter {
    constructor(x, y, velocity) {
        super('dejay',x, y, velocity)
        this.image = document.querySelector('img[alt="dejay"]');
    }
}

