import { Sagat } from "./sagat.js";
import { DeJay } from "./DeJay.js";
import { Stage} from "./stage.js";
import { FpsCounter } from "./FpsCounter.js";


const GameViwerPort = {
    width: 770,
    height: 500,
};

window.addEventListener('load', function() {
    const canvasElement = document.querySelector('canvas');
    const context = canvasElement.getContext('2d');
    
    canvasElement.width = GameViwerPort.width;
    canvasElement.height = GameViwerPort.height;

    
    const stage = new Stage();
    const sagat = new Sagat(80, 330, 150);
    const dejay = new DeJay(80, 350, -150);
    const fpscounter = new FpsCounter();
    
    
    let previousTime = 0;
    let secondsPassed = 0;

    function frame(time) {
        window.requestAnimationFrame(frame);
        
        secondsPassed = (time - previousTime) / 1000;
        previousTime = time;

        sagat.update(secondsPassed, context)
        dejay.update(secondsPassed, context)

        stage.draw(context)
        sagat.draw(context);
        dejay.draw(context);
        fpscounter.update(secondsPassed);
        fpscounter.draw(context);
       
        console.log(time)
    }    
    window.requestAnimationFrame(frame);
});