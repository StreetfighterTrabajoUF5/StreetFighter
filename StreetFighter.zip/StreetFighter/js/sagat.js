import { Fighter } from './fighter.js';

export class Sagat extends Fighter {
    constructor(x, y, velocity) {
        super('sagat',x, y, velocity)
        this.image = document.querySelector('img[alt="sagat"]');
    }
}


